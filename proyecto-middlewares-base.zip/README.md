# Vital · Práctica de middlewares

Node.js 22.9 o superior y Express. Ejecutar dentro de esta carpeta:

```sh
npm install
npm start
```

En PowerShell con scripts deshabilitados usar `npm.cmd install` y `npm.cmd start`.
Abrir http://localhost:3000. Los datos se conservan en `data/vital.json`.

## Credenciales de demostración

| Cuenta | Contraseña | Rol | Token API |
|---|---|---|---|
| ana | Ana123! | admin | abc123 |
| luis | Luis123! | user | xyz789 |

Las rutas GET de tareas son públicas. Ambos roles pueden crear; solamente admin elimina.
Son cuentas estáticas educativas, no un sistema de autenticación de producción.

## Explicación de middlewares

Express recorre la cadena en orden. Si `errorHandler` se registra antes de las rutas, no recibe los errores que estas envían posteriormente mediante `next(error)`: Express busca un manejador de errores a partir de la posición actual, sin volver atrás. Por eso debe ser el último.

Si un middleware no llama a `next()` y tampoco termina la respuesta, la petición queda pendiente hasta que se agote el tiempo de espera. Si ya envió la respuesta, no necesita continuar. `next(error)` salta al manejo de errores; `next()` continúa con el siguiente middleware normal.

## Almacenamiento autorizado

Se mantiene un arreglo de tareas en memoria y se respalda con escritura temporal y renombrado en JSON. Esta extensión a la consigna fue autorizada por el profesor según la indicación del estudiante. Se admite un solo proceso del servidor; no ejecutar varias instancias sobre el mismo archivo.
